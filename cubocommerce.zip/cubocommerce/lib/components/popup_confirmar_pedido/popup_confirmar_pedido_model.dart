import '/flutter_flow/flutter_flow_util.dart';
import 'popup_confirmar_pedido_widget.dart' show PopupConfirmarPedidoWidget;
import 'package:flutter/material.dart';

class PopupConfirmarPedidoModel
    extends FlutterFlowModel<PopupConfirmarPedidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
