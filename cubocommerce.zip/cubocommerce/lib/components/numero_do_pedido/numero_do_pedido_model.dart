import '/flutter_flow/flutter_flow_util.dart';
import 'numero_do_pedido_widget.dart' show NumeroDoPedidoWidget;
import 'package:flutter/material.dart';

class NumeroDoPedidoModel extends FlutterFlowModel<NumeroDoPedidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
