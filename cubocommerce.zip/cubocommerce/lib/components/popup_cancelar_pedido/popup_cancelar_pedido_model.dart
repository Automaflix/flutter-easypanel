import '/flutter_flow/flutter_flow_util.dart';
import 'popup_cancelar_pedido_widget.dart' show PopupCancelarPedidoWidget;
import 'package:flutter/material.dart';

class PopupCancelarPedidoModel
    extends FlutterFlowModel<PopupCancelarPedidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
