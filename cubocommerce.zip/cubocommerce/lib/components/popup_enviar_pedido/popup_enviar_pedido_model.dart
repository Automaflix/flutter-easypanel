import '/flutter_flow/flutter_flow_util.dart';
import 'popup_enviar_pedido_widget.dart' show PopupEnviarPedidoWidget;
import 'package:flutter/material.dart';

class PopupEnviarPedidoModel extends FlutterFlowModel<PopupEnviarPedidoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
