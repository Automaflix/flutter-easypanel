import '/flutter_flow/flutter_flow_util.dart';
import 'detalhes_produto_catalogo_widget.dart'
    show DetalhesProdutoCatalogoWidget;
import 'package:flutter/material.dart';

class DetalhesProdutoCatalogoModel
    extends FlutterFlowModel<DetalhesProdutoCatalogoWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
